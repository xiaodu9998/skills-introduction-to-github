# Cloud Automation Setup (GitHub Actions)

> 目标：无需服务器，在 GitHub Actions 上**定时**跑 `run_daily` / `run_weekly_report`，并把结果：
> - 作为 Artifact 下载；或
> - 提交回仓库；或
> - 推送到 Google Sheets / Notion（推荐，移动端查看最方便）。

## 一步步来

### 0）上传代码
把整个项目推到你的 GitHub 仓库（建议私有）。

### 1）配置 Secrets
进入仓库 → Settings → Secrets and variables → Actions → New repository secret：

- `NOTION_API_KEY`（可选）
- `NOTION_DATABASE_ID`（可选）
- `GOOGLE_CREDENTIALS_JSON`（可选，**内容是 credentials.json 的原始 JSON**）
- `CRUNCHBASE_API_KEY`（可选）
- `CONFIG_YAML_BASE64`（可选，把你的 `config.yaml` 以 Base64 编码后贴进去）
- `PUSH_BACK`：设为 `true` 可让工作流把新增的 CSV / 报告提交回仓库

> **Notion**：先在 Notion 建一个数据库（建议属性列：Title、Date、Source、URL、Label），把数据库 ID 复制到 `NOTION_DATABASE_ID`。
> **Google Sheets**：在 GCP 创建服务账号并开通 Sheets API，把生成的 `credentials.json` 内容全文复制到 `GOOGLE_CREDENTIALS_JSON`。在 `config.yaml` 填好 spreadsheet_id 与工作表名。

### 2）调整定时
打开 `.github/workflows/schedule.yml` 修改：
```yaml
- cron: "0 1 * * *"      # 每天 01:00 UTC 跑 run_daily
- cron: "30 1 * * 1"     # 每周一 01:30 UTC 跑周报
```
> 例：北京时间 = UTC+8。你也可以只保留一个 cron。

### 3）开启下游推送
在 `config.yaml` 中：
```yaml
sinks:
  gsheet:
    enabled: true
    spreadsheet_id: "你的SheetID"
    worksheets:
      vc_tracker: "VC_Tracker"
      tech_trends: "Tech_Trends"
  notion:
    enabled: true
    database_id: "你的Notion数据库ID"
```
并配置好上面的 Secrets。

### 4）看结果
- Actions → 选最近一次运行 → Artifacts 里可下载 `tracker-artifacts`（含 CSV 与报告/图表）。
- 若开启 `PUSH_BACK=true`：直接在仓库 `data/datastore/` 与 `reports/` 下查看更新。
- 若开启 Notion / Sheets：用手机直接看 Notion/Sheets，最省心。

---

## 常见问题
- **时区**：在 `config.yaml` 设置 `timezone`（例如 `Asia/Shanghai` 或 `America/Los_Angeles`）。
- **依赖太慢**：可把 `requirements.txt` 缓存，或自行构建容器镜像。

祝使用愉快！
