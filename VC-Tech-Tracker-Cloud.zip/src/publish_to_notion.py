import os, pandas as pd
from notion_client import Client
from .common import load_config

def upsert_rows(notion: Client, database_id: str, df: pd.DataFrame):
    for _, row in df.iterrows():
        props = {
            "Title": {"title": [{"text": {"content": str(row.get("title", ""))}}]},
            "Date": {"date": {"start": str(row.get("date", ""))}},
            "Source": {"rich_text": [{"text": {"content": str(row.get("source", ""))}}]},
            "URL": {"url": str(row.get("url", ""))},
            "Label": {"select": {"name": str(row.get("label", ""))}},
        }
        notion.pages.create(parent={"database_id": database_id}, properties=props)

def run(vc_path, tech_path):
    cfg = load_config()
    sink = cfg.get("sinks", {}).get("notion", {})
    if not sink.get("enabled"):
        print("notion sink disabled.")
        return
    import pandas as pd
    api_key = os.getenv("NOTION_API_KEY")
    db_id = sink.get("database_id") or os.getenv("NOTION_DATABASE_ID")
    if not api_key or not db_id:
        print("Missing NOTION_API_KEY or database_id.")
        return
    notion = Client(auth=api_key)

    if os.path.exists(tech_path):
        df = pd.read_csv(tech_path)
        upsert_rows(notion, db_id, df)
