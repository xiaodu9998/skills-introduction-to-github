import feedparser, requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from .common import load_config, ensure_storage_dir, tz_now

def extract_text(html, max_len=300):
    if not html:
        return ""
    soup = BeautifulSoup(html, "lxml")
    txt = soup.get_text(separator=" ", strip=True)
    return txt[:max_len]

def fetch_feeds(feed_urls):
    items = []
    for url in feed_urls:
        d = feedparser.parse(url)
        for e in d.entries:
            items.append({
                "title": e.get("title", ""),
                "summary": extract_text(e.get("summary", "")),
                "link": e.get("link", ""),
                "published": e.get("published", ""),
                "source": urlparse(url).netloc
            })
    return items

def is_funding_item(entry, keywords):
    content = (entry["title"] + " " + entry["summary"]).lower()
    return any(k.lower() in content for k in keywords)

def run():
    cfg = load_config()
    tzname = cfg.get("timezone", "UTC")
    now = tz_now(tzname).strftime("%Y-%m-%d")
    out_vc, out_tt = [], []

    if cfg.get("sources", {}).get("rss_vc", {}).get("enabled", False):
        feeds = cfg["sources"]["rss_vc"]["feeds"]
        vc_keys = cfg.get("keywords", {}).get("vc_funding", [])
        for e in fetch_feeds(feeds):
            if is_funding_item(e, vc_keys):
                out_vc.append({
                    "date": now,
                    "company": "",
                    "industry": "",
                    "round": "",
                    "amount": "",
                    "investors": "",
                    "source": e["source"],
                    "title": e["title"],
                    "url": e["link"]
                })

    if cfg.get("sources", {}).get("rss_tech", {}).get("enabled", False):
        feeds = cfg["sources"]["rss_tech"]["feeds"]
        for e in fetch_feeds(feeds):
            out_tt.append({
                "date": now,
                "keyword": "",
                "title": e["title"],
                "summary": e["summary"],
                "source": e["source"],
                "label": "",
                "url": e["link"]
            })
    return out_vc, out_tt

if __name__ == "__main__":
    print(run())
