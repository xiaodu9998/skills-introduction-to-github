import requests, xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from urllib.parse import urlencode
from .common import load_config, tz_now

ARXIV_API = "http://export.arxiv.org/api/query"

def parse_entry(entry):
    title = entry.find("{http://www.w3.org/2005/Atom}title").text.strip()
    summary = entry.find("{http://www.w3.org/2005/Atom}summary").text.strip()
    link = ""
    for l in entry.findall("{http://www.w3.org/2005/Atom}link"):
        if l.attrib.get("rel") == "alternate":
            link = l.attrib.get("href")
    return title, summary, link

def run():
    cfg = load_config()
    tzname = cfg.get("timezone", "UTC")
    now_str = tz_now(tzname).strftime("%Y-%m-%d")
    src_conf = cfg.get("sources", {}).get("arxiv", {})
    if not src_conf.get("enabled", False):
        return []

    days_back = int(src_conf.get("days_back", 3))
    start_date = (datetime.utcnow() - timedelta(days=days_back)).strftime("%Y-%m-%d")
    queries = src_conf.get("queries", [])
    max_results = int(src_conf.get("max_results", 50))

    rows = []
    for q in queries:
        params = {
            "search_query": f"all:{q}",
            "start": 0,
            "max_results": max_results,
            "sortBy": "submittedDate",
            "sortOrder": "descending"
        }
        resp = requests.get(ARXIV_API, params=params, timeout=20)
        resp.raise_for_status()
        root = ET.fromstring(resp.text)
        for entry in root.findall("{http://www.w3.org/2005/Atom}entry"):
            title, summary, link = parse_entry(entry)
            rows.append({
                "date": now_str,
                "keyword": q,
                "title": title,
                "summary": summary[:300],
                "source": "arxiv.org",
                "label": "",
                "url": link
            })
    return rows

if __name__ == "__main__":
    print(run())
