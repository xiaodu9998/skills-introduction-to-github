import os, re, csv, yaml, hashlib
from datetime import datetime, timezone, timedelta
from dateutil import tz

def load_config(path="config.yaml"):
    if not os.path.exists(path):
        path = "config.example.yaml"
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def ensure_storage_dir(cfg):
    d = cfg.get("storage_dir", "data/datastore")
    os.makedirs(d, exist_ok=True)
    return d

def tz_now(tz_name):
    zone = tz.gettz(tz_name)
    return datetime.now(zone)

def slugify(s: str) -> str:
    s = re.sub(r"[^\w\-]+", "-", s, flags=re.UNICODE)
    return s.strip("-").lower()

def row_hash(row: dict) -> str:
    key = "|".join(str(v) for v in row.values())
    return hashlib.sha1(key.encode("utf-8")).hexdigest()

def append_csv_dedup(path: str, rows: list, key_fields=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    existing = set()
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for r in reader:
                if key_fields:
                    key = "|".join(r.get(k, "") for k in key_fields)
                else:
                    key = row_hash(r)
                existing.add(key)
    mode = "a" if os.path.exists(path) else "w"
    with open(path, mode, encoding="utf-8", newline="") as f:
        if rows:
            writer = None
            for r in rows:
                if key_fields:
                    key = "|".join(str(r.get(k, "")) for k in key_fields)
                else:
                    key = row_hash(r)
                if key in existing:
                    continue
                if writer is None:
                    writer = csv.DictWriter(f, fieldnames=list(r.keys()))
                    if mode == "w":
                        writer.writeheader()
                writer.writerow(r)
