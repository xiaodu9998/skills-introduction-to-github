import os, pandas as pd
from google.oauth2 import service_account
from googleapiclient.discovery import build
from .common import load_config

def df_to_sheet(service, spreadsheet_id, sheet_name, df):
    body = {
        "valueInputOption": "RAW",
        "data": [
            {"range": f"{sheet_name}!A1", "values": [df.columns.tolist()] + df.values.tolist()}
        ]
    }
    service.spreadsheets().values().batchUpdate(
        spreadsheetId=spreadsheet_id, body=body).execute()

def run(vc_path, tech_path):
    cfg = load_config()
    sink = cfg.get("sinks", {}).get("gsheet", {})
    if not sink.get("enabled"):
        print("gsheet sink disabled.")
        return

    spreadsheet_id = sink.get("spreadsheet_id")
    ws = sink.get("worksheets", {})
    creds_path = "credentials.json"  # 服务账号或 OAuth 凭据
    if not os.path.exists(creds_path):
        print("Missing credentials.json")
        return

    # 使用服务账号 JSON（推荐在服务器端）
    credentials = service_account.Credentials.from_service_account_file(creds_path, scopes=[
        "https://www.googleapis.com/auth/spreadsheets"
    ])
    service = build("sheets", "v4", credentials=credentials)

    if os.path.exists(vc_path):
        df = pd.read_csv(vc_path)
        df_to_sheet(service, spreadsheet_id, ws.get("vc_tracker", "VC_Tracker"), df)
    if os.path.exists(tech_path):
        df = pd.read_csv(tech_path)
        df_to_sheet(service, spreadsheet_id, ws.get("tech_trends", "Tech_Trends"), df)
