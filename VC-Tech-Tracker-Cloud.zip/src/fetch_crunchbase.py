import os, requests
from .common import load_config

API_URL = "https://api.crunchbase.com/api/v4/entities/organizations"

def run():
    cfg = load_config()
    conf = cfg.get("sources", {}).get("crunchbase", {})
    if not conf.get("enabled"):
        return []
    api_key = os.getenv("CRUNCHBASE_API_KEY")
    if not api_key:
        print("CRUNCHBASE_API_KEY not set; skip.")
        return []

    # 这里只给出示例调用，真实查询请参考官方文档与你账户权限
    params = {
        "user_key": api_key,
        "domain": "crunchbase.com",
        "limit": 20
    }
    r = requests.get(API_URL, params=params, timeout=20)
    if r.status_code != 200:
        print("Crunchbase API error:", r.status_code, r.text[:200])
        return []
    data = r.json()
    # 解析逻辑留空：不同端点返回结构不同，请按需补充
    return []

if __name__ == "__main__":
    print(run())
