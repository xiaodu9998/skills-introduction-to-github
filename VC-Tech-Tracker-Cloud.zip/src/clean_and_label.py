import re
from .common import load_config

def apply_labels(rows, label_map):
    for r in rows:
        text = " ".join(str(r.get(k, "")) for k in ["title", "summary", "keyword"]).lower()
        for label, kws in label_map.items():
            if any(kw.lower() in text for kw in kws):
                r["label"] = label
                break
    return rows

def normalize_industry(title):
    # 可按需扩展：基于关键词/模型推断行业
    if not title:
        return ""
    t = title.lower()
    if "ai" in t or "ml" in t or "模型" in t:
        return "AI"
    if "robot" in t or "机器人" in t:
        return "机器人"
    if "battery" in t or "电池" in t:
        return "新能源"
    return ""

def enrich_vc_rows(rows):
    for r in rows:
        if not r.get("industry"):
            r["industry"] = normalize_industry(r.get("title", ""))
    return rows

def run(vc_rows, tech_rows):
    cfg = load_config()
    label_map = cfg.get("label_map", {})
    tech_rows = apply_labels(tech_rows, label_map)
    vc_rows = enrich_vc_rows(vc_rows)
    return vc_rows, tech_rows
