import os, pandas as pd
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from .common import load_config, ensure_storage_dir

def week_range(today=None):
    today = today or datetime.today().date()
    start = today - timedelta(days=today.weekday())  # Monday
    end = start + timedelta(days=6)
    return start, end

def plot_counts(df, date_col, title, out_png):
    if df.empty:
        return
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce").dt.date
    counts = df.groupby(date_col).size().sort_index()
    plt.figure()
    counts.plot(kind="line", marker="o")
    plt.title(title)
    plt.xlabel("Date")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(out_png)
    plt.close()

def main():
    cfg = load_config()
    store = ensure_storage_dir(cfg)
    vc_path = os.path.join(store, "vc_tracker.csv")
    tt_path = os.path.join(store, "tech_trends.csv")
    out_dir = "reports"
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(os.path.join(out_dir, "plots"), exist_ok=True)

    start, end = week_range()
    report_name = f"weekly_{start}_to_{end}.md"
    report_path = os.path.join(out_dir, report_name)

    vc = pd.read_csv(vc_path) if os.path.exists(vc_path) else pd.DataFrame()
    tt = pd.read_csv(tt_path) if os.path.exists(tt_path) else pd.DataFrame()

    vc_plot = os.path.join(out_dir, "plots", f"vc_counts_{start}_to_{end}.png")
    tt_plot = os.path.join(out_dir, "plots", f"tech_counts_{start}_to_{end}.png")

    plot_counts(vc, "date", "VC Funding Mentions (RSS/News)", vc_plot)
    plot_counts(tt, "date", "Tech Trends (RSS/arXiv)", tt_plot)

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"# Weekly Report: {start} ~ {end}\n\n")
        f.write("## Highlights\n\n- 本周自动摘要：请结合图表与明细人工补充要点。\n\n")
        if os.path.exists(vc_plot):
            f.write(f"![VC counts]({vc_plot})\n\n")
        if os.path.exists(tt_plot):
            f.write(f"![Tech counts]({tt_plot})\n\n")
        f.write("## Data Sources\n- RSS: Techmeme, TechCrunch, 36氪, MIT TR, Product Hunt, The Verge\n- arXiv API\n")
    print("Report:", report_path)

if __name__ == "__main__":
    main()
