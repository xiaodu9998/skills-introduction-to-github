import os, pandas as pd
from .common import load_config, ensure_storage_dir, append_csv_dedup
from .fetch_rss import run as run_rss
from .fetch_arxiv import run as run_arxiv
from .clean_and_label import run as run_clean
from .publish_to_gsheets import run as sink_gs
from .publish_to_notion import run as sink_notion

def main():
    cfg = load_config()
    store = ensure_storage_dir(cfg)
    vc_rows, tech_rows = run_rss()
    arxiv_rows = run_arxiv()
    tech_rows.extend(arxiv_rows)

    vc_rows, tech_rows = run_clean(vc_rows, tech_rows)

    vc_path = os.path.join(store, "vc_tracker.csv")
    tt_path = os.path.join(store, "tech_trends.csv")

    append_csv_dedup(vc_path, vc_rows, key_fields=["url"])
    append_csv_dedup(tt_path, tech_rows, key_fields=["url"])

    # 可选下游
    try:
        sink_gs(vc_path, tt_path)
    except Exception as e:
        print("gsheets sink error:", e)
    try:
        sink_notion(vc_path, tt_path)
    except Exception as e:
        print("notion sink error:", e)

    print(f"Saved: {vc_path}, {tt_path}")

if __name__ == "__main__":
    main()
