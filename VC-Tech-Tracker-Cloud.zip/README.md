# VC & Tech Tracker (自动化追踪：投资动向 × 全球技术趋势)

一个最小可用（MVP）的自动化情报管线：
- 每日抓取：RSS/新闻/（可选）arXiv 论文与（可选）Crunchbase/IT桔子。
- 每周汇总：自动生成周报与趋势图。
- 统一入库：CSV/Excel；（可选）同步至 Google Sheets / Notion。

> **注意**：本项目默认以 RSS 与 arXiv 为基础（无需付费 API）。Crunchbase/IT桔子/Dealroom 需你在 `config.yaml` 中填入 API Key 后开启。

## 目录结构
```
VC-Tech-Tracker/
  ├── README.md
  ├── requirements.txt
  ├── config.example.yaml
  ├── .env.example
  ├── data/
  │   ├── templates/
  │   │   ├── vc_tracker.csv
  │   │   └── tech_trends.csv
  │   └── datastore/    # 运行后自动创建
  ├── reports/
  │   └── plots/
  └── src/
      ├── common.py
      ├── fetch_rss.py
      ├── fetch_arxiv.py
      ├── fetch_crunchbase.py      # 可选
      ├── clean_and_label.py
      ├── publish_to_gsheets.py    # 可选
      ├── publish_to_notion.py     # 可选
      ├── run_daily.py
      └── run_weekly_report.py
```

## 快速开始
1) **下载依赖**
```bash
pip install -r requirements.txt
```
2) **复制配置**：将 `config.example.yaml` 复制为 `config.yaml` 并按需修改；将 `.env.example` 复制为 `.env`（如需 Google Sheets/Notion/Crunchbase）。
3) **首次运行**
```bash
python -m src.run_daily
python -m src.run_weekly_report
```
- 产出：`data/datastore/*.csv`（追加写入）；`reports/weekly_*.md` 与 `reports/plots/*.png`。

4) **（可选）同步到 Google Sheets**
   - 下载 Google API 凭据（`credentials.json`）放在项目根目录；参见 `src/publish_to_gsheets.py`。
5) **（可选）同步到 Notion**
   - 在 `.env` 中配置 `NOTION_API_KEY` 与 `NOTION_DATABASE_ID`；参见 `src/publish_to_notion.py`。

## 定时运行（cron 示例）
使用 `crontab -e`：
```
# 每天 08:00 运行
0 8 * * * cd /path/to/VC-Tech-Tracker && /usr/bin/python3 -m src.run_daily >> cron.log 2>&1
# 每周一 08:30 生成周报
30 8 * * 1 cd /path/to/VC-Tech-Tracker && /usr/bin/python3 -m src.run_weekly_report >> cron.log 2>&1
```

## 行业/技术标签
- 通过 `config.yaml` 的 `keywords` 与 `label_map` 自动打标签，后续可在可视化中筛选。

## 免责声明
本仓库仅供信息聚合与研究用途；请遵守各站点的使用条款与机器人协议（robots.txt）。
